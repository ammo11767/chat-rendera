<?php
header('Content-Type: application/json');
$pdo = new PDO("sqlite:chat.db");
$data = $pdo->query("SELECT nombre, lat, lng FROM usuarios WHERE lat IS NOT NULL AND lng IS NOT NULL")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($data);
?>