<?php
header('Content-Type: application/json');
header('Cache-Control: no-store');
$pdo = new PDO('sqlite:chat.db');
echo json_encode(
  $pdo->query('SELECT nombre, lat, lng FROM usuarios ORDER BY nombre')
      ->fetchAll(PDO::FETCH_ASSOC)
);
?>